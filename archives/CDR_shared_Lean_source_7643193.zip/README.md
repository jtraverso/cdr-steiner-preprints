# cdr-bicolour-lean

Formalización en Lean 4 de la ruta candidata a la conjetura de Colbourn–Dinitz–Rosa.

**La conjetura.** Para toda terna (a,b,c) con n = a+b+c ≡ 1,3 (mod 6), a²+b²+c²−ab−ac−bc = n y (a,b,c) ≠ (2,2,5), existe un STS(n) con una 3-bicoloración estricta de clases de tamaños a, b, c.

**Estado:** L184 (ensamblaje final) y el Lema 1.3 de Plantholt están formalizados; ver `GATES.md` y `docs/PLAN_FORMALIZACION.md`. Los teoremas externos aparecen solo como enunciados con nombre, por formalizar.

**Mathlib compartida.** `.lake/packages` no es una instalación propia: son junctions hacia `C:\nw\nash-williams-lean\.lake\packages`, la versión Palomar (Lean v4.35.0-rc3, Mathlib c55e6e78), con la misma convención que `typed-triangle-absorption`. En otra máquina se recrean con `tools/link_shared_packages.ps1`. No se debe ejecutar `lake update`: modificaría la instalación compartida.

**Build** (un proceso a la vez):

```
lake build CDRBicolour.P2Family CDRBicolour.EdgeColouring.Plantholt13 CDRBicolour.EdgeColouring.OverfullThree CDRBicolour.EdgeColouring.Basic CDRBicolour.L184.Assembly
```

**Estructura:**
- `CDRBicolour/`: desarrollo propio.
- `LeanPool/Vizing/`: Vizing y coloreo equitativo reutilizados; ver `PROVENANCE.md`.
- `research/`: paquete de la ruta candidata y auditoría.
- `docs/`: plan.
