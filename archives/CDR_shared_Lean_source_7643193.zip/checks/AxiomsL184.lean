import CDRBicolour.L184.Assembly
#print axioms CDRBicolour.L184.l184_assembly
#print axioms CDRBicolour.L184.card_omitted_fibre
#print axioms CDRBicolour.exists_pairing_of_even_fibres
#print axioms CDRBicolour.exists_conj_of_card_eq
