import CDRBicolour.Absorption.Lattice
#print axioms CDRBicolour.Absorption.cdr_H2
#print axioms CDRBicolour.Absorption.cdr_H2_of_three
#check @CDRBicolour.Absorption.cdr_H2
