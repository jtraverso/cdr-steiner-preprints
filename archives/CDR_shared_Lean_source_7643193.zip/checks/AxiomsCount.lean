import CDRBicolour.Absorption.Count.ProfileCount
#print axioms CDRBicolour.Absorption.Count.realCount_lower
#print axioms CDRBicolour.Absorption.Count.realCount_upper
