import CDRBicolour
#print axioms CDRBicolour.cdr_conjecture
