import CDRBicolour.Absorption.Host
#print axioms CDRBicolour.Absorption.cdr_H1
#print axioms CDRBicolour.Absorption.cdr_H3
#check @CDRBicolour.Absorption.cdr_H1
