import CDRBicolour.Absorption.ResidualSeedCDR
#print axioms CDRBicolour.Absorption.cdr_residual_seed
#print axioms CDRBicolour.Absorption.bri_of_balanced
