import CDRBicolour.Absorption.Count.Wilson.Final
#print axioms CDRBicolour.Absorption.Count.Wilson.wilson_core
#print axioms CDRBicolour.Absorption.Count.Wilson.realCount_lower_sharp
#print axioms CDRBicolour.Absorption.Count.Wilson.realCount_log_asymptotic
