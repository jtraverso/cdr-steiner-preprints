import CDRBicolour.Characterization
#print axioms CDRBicolour.Palomar.bkls_corollary_12
#print axioms CDRBicolour.Palomar.rs_theorem_3_1
#print axioms CDRBicolour.cdr_conjecture
#print axioms CDRBicolour.cdr_characterization
#print axioms CDRBicolour.cdr_characterization_bicolourable3
#print axioms CDRBicolour.Palomar.admissible_of_realises
