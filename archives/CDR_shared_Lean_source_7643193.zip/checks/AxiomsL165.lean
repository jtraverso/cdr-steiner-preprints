import CDRBicolour.Descent.L165
#print axioms CDRBicolour.Descent.descent_composite
#print axioms CDRBicolour.Descent.split_one
#print axioms CDRBicolour.Descent.thue
