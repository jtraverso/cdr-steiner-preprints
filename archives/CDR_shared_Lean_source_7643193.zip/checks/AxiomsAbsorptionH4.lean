import CDRBicolour.Absorption.Hinge
#print axioms CDRBicolour.Absorption.cdr_H4
#print axioms CDRBicolour.Absorption.cdr_H3'
#check @CDRBicolour.Absorption.cdr_H4
