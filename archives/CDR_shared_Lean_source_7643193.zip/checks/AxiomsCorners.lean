import CDRBicolour.Absorption.Corners.Spectrum

#print axioms CDRBicolour.Absorption.Corners.cdr_type_spectrum
#print axioms CDRBicolour.Absorption.Corners.corner_lower
#print axioms CDRBicolour.Absorption.Corners.lower_nec
