import CDRBicolour.EdgeColouring.OverfullThree
import CDRBicolour.Profile
import CDRBicolour.P2Family
import CDRBicolour.EdgeColouring.Plantholt13
import LeanPool.Vizing

#print axioms CDRBicolour.pair_count_iff
#print axioms CDRBicolour.two_two_forces_five
#print axioms CDRBicolour.P2.quadratic_identity
#print axioms CDRBicolour.P2.bbc_edges
#print axioms CDRBicolour.P2.star_budget
#print axioms CDRBicolour.P2.plantholt_sq
#print axioms CDRBicolour.P2.ccjs_margin
#print axioms CDRBicolour.P2.overfull_excess_nonpos
#print axioms CDRBicolour.plantholt_lemma_1_3
#print axioms LeanPool.Vizing.exists_equitable_edge_colouring
#print axioms CDRBicolour.inducesOverfull_iff
#print axioms CDRBicolour.singleton_full
