import CDRBicolour.Extensions.BlockTypes
#print axioms CDRBicolour.BlockTypes.typeCount_lower
#print axioms CDRBicolour.BlockTypes.realised_lower_C_odd
#print axioms CDRBicolour.BlockTypes.classSize_eq_local
#print axioms CDRBicolour.BlockTypes.realised_type_identities
