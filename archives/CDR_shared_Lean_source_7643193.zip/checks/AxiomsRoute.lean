import CDRBicolour.Route
#print axioms CDRBicolour.cdr_conjecture_of_branches
#print axioms CDRBicolour.Base.realises_of_table
#print axioms CDRBicolour.branchL161_of
#print axioms CDRBicolour.branchL160_of
