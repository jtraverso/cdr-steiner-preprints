import CDRBicolour.Absorption.Asymptotic
import CDRBicolour.Absorption.Spectrum
import CDRBicolour.Absorption.PaschDiversity
import CDRBicolour.Absorption.Completion
#print axioms CDRBicolour.Absorption.cdr_eventually
#print axioms CDRBicolour.Absorption.cdr_aac_spectrum
#print axioms CDRBicolour.Absorption.cdr_aac_dense
#print axioms CDRBicolour.Absorption.cdr_many_aac_counts
#print axioms CDRBicolour.Absorption.PaschSeed.cdr_many_pasch_counts
#print axioms CDRBicolour.Absorption.PaschSeed.cdr_many_nonisomorphic
#print axioms CDRBicolour.Absorption.cdr_completion
