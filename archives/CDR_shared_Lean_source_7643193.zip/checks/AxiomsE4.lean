import CDRBicolour.Lift
#print axioms CDRBicolour.cdr_product
#print axioms CDRBicolour.realises_product
#print axioms CDRBicolour.realises_lift
#print axioms CDRBicolour.realises_rotate
#print axioms CDRBicolour.realises_swap
#print axioms CDRBicolour.Latin.forbidden_latin
#print axioms CDRBicolour.Latin.ryser
