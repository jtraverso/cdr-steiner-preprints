import CDRBicolour
#print axioms CDRBicolour.Base.gridOK_eq
#print axioms OneFactor.lineGraph_colorable_of_isRegular67
#print axioms OneFactor.overfull_criterion67
