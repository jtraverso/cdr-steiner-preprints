import CDRBicolour.Absorption.ResidualSeed
#print axioms CDRBicolour.Absorption.residual_seed_of_bri
#print axioms CDRBicolour.Absorption.residual_physical
#print axioms CDRBicolour.Absorption.residual_H4
#print axioms CDRBicolour.Absorption.residual_H3
