import CDRBicolour.Master.Equitable
#print axioms CDRBicolour.Master.eqMaster_realises
#print axioms CDRBicolour.Master.master_assembly
