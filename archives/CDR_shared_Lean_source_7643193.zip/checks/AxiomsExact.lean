import CDRBicolour.Absorption.Exact.Final
#print axioms CDRBicolour.Absorption.Exact.cdr_aac_exact
