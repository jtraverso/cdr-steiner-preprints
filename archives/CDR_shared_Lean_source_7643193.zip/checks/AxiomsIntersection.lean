import CDRBicolour.Absorption.Refined.Completion
#print axioms CDRBicolour.Absorption.Refined.cdr_prescribed_intersection
#print axioms CDRBicolour.Absorption.Refined.refined_completion
