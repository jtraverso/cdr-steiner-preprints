import CDRBicolour.P2Route
#print axioms CDRBicolour.Prefix.P2_realises
#print axioms CDRBicolour.Prefix.stageA
#print axioms CDRBicolour.Prefix.stageB
#print axioms CDRBicolour.Prefix.hall_stars
#print axioms CDRBicolour.Prefix.prefix_cover
