import CDRBicolour.P2RouteClosed
#print axioms CDRBicolour.L181.l181_noAnchor
#print axioms CDRBicolour.L181.l181_star
#print axioms CDRBicolour.L181.l181_noAnchorB
#print axioms CDRBicolour.L181.l181_starB
#print axioms CDRBicolour.L181.maxmatch_bound
#print axioms CDRBicolour.L181.port_move
#print axioms CDRBicolour.L181.exists_flip_set
#print axioms CDRBicolour.Prefix.P2_realises'
