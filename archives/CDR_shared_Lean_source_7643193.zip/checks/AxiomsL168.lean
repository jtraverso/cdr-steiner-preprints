import CDRBicolour.Route
#print axioms CDRBicolour.branchL168y_of
#print axioms CDRBicolour.Master.x4_core
#print axioms CDRBicolour.Master.master_core
