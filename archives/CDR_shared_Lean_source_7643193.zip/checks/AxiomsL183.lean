import CDRBicolour.L183.P2
#print axioms CDRBicolour.L183.l183
#print axioms CDRBicolour.L183.l183_P2
#print axioms CDRBicolour.L183.step1
#print axioms CDRBicolour.L183.step2
#print axioms CDRBicolour.edgeColourable_of_edgeColourable_restrict
#print axioms CDRBicolour.exists_critical_subgraph
