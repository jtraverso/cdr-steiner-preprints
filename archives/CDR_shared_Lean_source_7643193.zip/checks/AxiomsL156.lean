import CDRBicolour.L156.Theorem
#print axioms CDRBicolour.L156.l156
#print axioms CDRBicolour.L156.port_moveQ
#print axioms CDRBicolour.L156.maxmatch_boundQ
