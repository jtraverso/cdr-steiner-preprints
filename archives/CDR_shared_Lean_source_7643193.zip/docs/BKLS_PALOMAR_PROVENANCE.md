# Procedencia: Balister–Kostochka–Li–Schelp (2004), Corolario 12

- Repositorio: `jtraverso/balanced-edge-colourings` @ `736c78e` (Teoremas 1, 6, 10(2) y Corolario 12).
- Palomar: envío **zkpg2vegzyle**, preflight aprobado, aceptado 2026-11-05T03:55Z. **Pendiente de registro**
  (id `PALOMAR-…` por asignar; actualizar este archivo, `lakefile.toml` y `GATES.md` cuando llegue).
- Uso en este árbol: dependencia de ruta `bkls_balanced` (`C:/cdr-deps/balanced-edge-colourings`), entrada de
  manifiesto agregada a mano (sin `lake update`). Su requisito `plantholt_overfull @ f890094` queda sombreado por
  el nuestro (`@ 28ff33d`, PALOMAR-2026-11-04-000016); `Balanced/` es idéntico en ambas revisiones.
- Puente: `CDRBicolour/Palomar/BKLS.lean`, `Palomar.bkls_corollary_12 : Master.BKLS_Corollary_12.{0}`, desde el
  enunciado comparado `BklsPalomar.corollary12`.
