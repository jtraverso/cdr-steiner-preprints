# Counting STS (Palomar): provenance of the isolated cone

- Palomar entry **PALOMAR-2026-10-22-000017**, version 2: `jtraverso/counting-steiner-triple-systems` @ `52fda83038df7442c576e17edffba591db703cb8` (Wilson 1974, Linial–Luria 2013, van der Waerden via Gurvits; no `native_decide`).
- Lake cannot host two packages with the same module root (`RequestProject` is also Paper III's). The 27 modules of the cone of `RequestProject.VanDerWaerden.Full` and `RequestProject.LL.STSMain` were copied to `C:/cdr-deps/counting-sts-cone`, with the module root renamed to `CountingCone`. **Only import lines change.**
- SHA-256 of every original file and of its renamed copy: `docs/COUNTING_CONE_SOURCES.sha256`. Script: `mk_cone.py` (scratchpad).
- Used:
  - `STS.hL_one STS.van_der_waerden`: `m²(log m − 2) ≤ log L(m)` (Latin squares);
  - `LinialLuria.sts_upper_bound_explicit`: Linial–Luria with an explicit error term.