# CCJS 1.2: Palomar provenance

- Palomar entry: **PALOMAR-2026-11-04-000009**, version 2 (registered 2026-11-04T14:33:45Z, status
  registered). Source: `jtraverso/overfull-critical-graphs`, commit
  `b85da9ac66e0fb8b9873a8bea0c057f78c9d186c`; preservation fork
  `PalomarArchive/jtraverso--overfull-critical-graphs--d8fd3a0c3ee4`. Theorems:
  `Overfull.overfull_of_critical`, `Overfull.overfull_of_critical_cc`,
  `Overfull.overfull_of_critical_ccjs`.
- Local dependency `ccjs_overfull` = `C:/cdr-deps/overfull-critical-graphs` at exactly that commit.
- Used: `Overfull.overfull_of_critical_ccjs` (CCJS Theorem 1.2, original constant, with `n + δ ≥ 27`),
  through `CDRBicolour/EdgeColouring/CCJSBridge.lean` (`ccjs_large`).
- Its dependency `vizing` (PALOMAR-2026-10-15-000004, `jtraverso/vizing` @ `33b2de8`) is served by
  the vendored `LeanPool.Vizing.*` of this repository (identical git blobs for the imported cone),
  through the empty shim package `C:/cdr-deps/vizing-shim`.
