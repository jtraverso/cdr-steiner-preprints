# Paper III dependency: provenance

- Source: `C:\nw\physical-typed-absorption` (Paper III library; `PAPER_III_FINAL_STATUS.json`:
  `TypedTriangle.Vortex.main_theorem_T`, source sha256 `7a49979e…dd92`, Lean 4.35.0-rc3,
  Mathlib c55e6e78).
- Copied: only the `.lean` files in the import cone of `MainPaperIII`,
  `MainPaperIIITriangleMonitors` and `MainPaperIIIPasch` (999 modules), to
  `C:/cdr-deps/physical-typed-absorption`. The original tree's `.olean` files were not used
  (hardlinked, without Lake traces).
- `docs/PAPER_III_DEP_SOURCES.sha256`: hashes of the copied sources **as in the original**.
- Build options. The original library is compiled with `-DmaxHeartbeats=1600000
  -DmaxRecDepth=8192` (see `tools/build_*.py` in the original tree). Under Lake's defaults,
  `RequestProject.TypedTriangle.CorePaidWindow` hits the 200000-heartbeat limit. To reproduce
  the original options without rebuilding the modules already compiled, the two lines
  ```
  set_option maxHeartbeats 1600000 -- build option (original: -DmaxHeartbeats=1600000)
  set_option maxRecDepth 8192 -- build option (original: -DmaxRecDepth=8192)
  ```
  were inserted right after the imports of the 792 modules not yet built at that point.
  File-local `set_option`s later in each file still take precedence, exactly as with `-D`.
  No other change. Hashes after the insertion: `docs/PAPER_III_DEP_SOURCES_BUILD.sha256`.
- 04-11-2026, a pedido del usuario: en los 776 módulos aún pendientes los límites se subieron a
  `maxHeartbeats 4000000` y `maxRecDepth 16384` (comentario `raised`). Subir límites sólo permite más
  cómputo; no cambia el significado de lo que compila.
