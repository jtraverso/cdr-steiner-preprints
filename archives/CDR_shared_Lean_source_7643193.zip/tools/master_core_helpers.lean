/-- The non-degenerate pairs inside a finite set. -/
def pairsOf {Cl : Type*} [DecidableEq Cl] (S : Finset Cl) : Finset (Sym2 Cl) :=
  S.sym2.filter fun e => ¬ e.IsDiag

theorem pairsOf_pair {Cl : Type*} [DecidableEq Cl] {x y : Cl} (hxy : x ≠ y) :
    pairsOf ({x, y} : Finset Cl) = {s(x, y)} := by
  ext e
  induction e using Sym2.ind with
  | _ u v =>
    simp only [pairsOf, mem_filter, mem_sym2_iff, Sym2.mem_iff, mem_insert, mem_singleton,
      Sym2.mk_isDiag_iff, Sym2.eq_iff]
    constructor
    · rintro ⟨h, huv⟩
      rcases h u (Or.inl rfl) with rfl | rfl <;> rcases h v (Or.inr rfl) with rfl | rfl
      · exact absurd rfl huv
      · exact Or.inl ⟨rfl, rfl⟩
      · exact Or.inr ⟨rfl, rfl⟩
      · exact absurd rfl huv
    · rintro (⟨rfl, rfl⟩ | ⟨rfl, rfl⟩)
      · exact ⟨fun w hw => by rcases hw with rfl | rfl <;> simp, hxy⟩
      · exact ⟨fun w hw => by rcases hw with rfl | rfl <;> simp, Ne.symm hxy⟩

theorem isPerfectPairing_pairsOf {Cl : Type*} [DecidableEq Cl] {S : Finset Cl}
    (h : S.card = 2) : IsPerfectPairing (pairsOf S) S := by
  obtain ⟨x, y, hxy, rfl⟩ := card_eq_two.1 h
  rw [pairsOf_pair hxy]
  refine ⟨fun e he => by rw [mem_singleton] at he; subst he; exact (Sym2.mk_isDiag_iff).not.2 hxy,
    fun e he v hv => ?_, fun v hv => ⟨s(x, y), ⟨mem_singleton_self _, ?_⟩,
      fun e he => mem_singleton.1 he.1⟩⟩
  · rw [mem_singleton] at he; subst he
    rcases Sym2.mem_iff.1 hv with rfl | rfl <;> simp
  · rcases mem_insert.1 hv with rfl | hv
    · exact Sym2.mem_mk_left _ _
    · rw [mem_singleton] at hv; subst hv; exact Sym2.mem_mk_right _ _

theorem pairsOf_disjoint {Cl : Type*} [DecidableEq Cl] {S T : Finset Cl} (hS : S.card = 2)
    (hT : T.card = 2) (hST : S ≠ T) : Disjoint (pairsOf S) (pairsOf T) := by
  obtain ⟨x, y, hxy, rfl⟩ := card_eq_two.1 hS
  obtain ⟨u, v, huv, rfl⟩ := card_eq_two.1 hT
  rw [pairsOf_pair hxy, pairsOf_pair huv, disjoint_singleton]
  intro h
  apply hST
  rcases Sym2.eq_iff.1 h with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩
  · rfl
  · exact pair_comm _ _

