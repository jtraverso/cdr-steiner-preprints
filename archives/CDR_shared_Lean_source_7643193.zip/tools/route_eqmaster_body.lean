theorem sq_mod_two (x : ℕ) : (x * x) % 2 = x % 2 := by
  rcases Nat.even_or_odd x with ⟨k, rfl⟩ | ⟨k, rfl⟩ <;> ring_nf <;> omega

/-- Bounds `k₁ ≤ ⌊E/B⌋ ≤ k₀` (`E = A(A-1)/2`) suffice for the equitable master hypotheses. -/
theorem eqMasterHyp_of_bounds {A B C k₀ k₁ : ℕ}
    (h1 : C % 2 = 0) (h2 : A < C) (h3 : A < B) (h4 : (B - A) % 2 = 1) (h5 : 3 ≤ B - A)
    (h6 : 6 * (C - A - 1) ≤ C) (h7 : 6 * C ≤ 7 * A)
    (hk₁ : 2 * k₁ * B ≤ A * (A - 1)) (hk₀ : A * (A - 1) < 2 * (k₀ + 1) * B)
    (hhi : 6 * (A - 2 * k₁) ≤ B) (hlo : B + 5 ≤ A - 2 * k₀ + C) : Master.EqMasterHyp A B C := by
  have hE2 : 2 * (A * (A - 1) / 2) = A * (A - 1) :=
    Nat.two_mul_div_two_of_even (Nat.even_mul_pred_self A)
  have hKB : A * (A - 1) / 2 / B * B ≤ A * (A - 1) / 2 := Nat.div_mul_le_self _ _
  have hKB' : A * (A - 1) / 2 < (A * (A - 1) / 2 / B + 1) * B := by
    have := Nat.div_add_mod (A * (A - 1) / 2) B
    have := Nat.mod_lt (A * (A - 1) / 2) (by omega : 0 < B)
    nlinarith
  unfold Master.EqMasterHyp
  generalize A * (A - 1) / 2 / B = K at hKB hKB' ⊢
  generalize A * (A - 1) / 2 = E at hKB hKB' hE2
  have hK1 : k₁ < K + 1 := Nat.lt_of_mul_lt_mul_right (a := B) (by nlinarith)
  have hK0 : K < k₀ + 1 := Nat.lt_of_mul_lt_mul_right (a := B) (by nlinarith)
  exact ⟨h1, h2, h3, h4, h5, h6, h7, by omega, by omega⟩

/-- `2k(A+t) ≤ A(A-1)` when `A = t + δ + 2k`, `δ ≥ 1`. -/
theorem hk1_gen (t δ k : ℕ) (hδ : 1 ≤ δ) :
    2 * k * (t + δ + 2 * k + t) ≤ (t + δ + 2 * k) * (t + δ + 2 * k - 1) := by
  obtain ⟨e, rfl⟩ : ∃ e, δ = e + 1 := ⟨δ - 1, by omega⟩
  rw [show t + (e + 1) + 2 * k - 1 = t + e + 2 * k by omega]
  nlinarith

/-! ### L160 -/

/-- Gap `y = 1` of L160 via the equitable master criterion. -/
theorem master_y1 (hCH : Master.ChetwyndHilton_1985.{0}) {a b c : ℕ}
    (hadm : AdmissibleProfile a b c) (hab : a ≤ b) (hc : c = b + 1) (hce : c % 2 = 0)
    (h5 : 5059 ≤ a + b + c) : Realises a b c := by
  have hg := order_gaps hadm hab (by omega)
  obtain ⟨x, hx⟩ : ∃ x, b = a + x := ⟨b - a, by omega⟩
  rw [show b - a = x by omega, show c - b = 1 by omega, sq, sq] at hg
  have h3a : 3 * a + x = x * x := by omega
  have hx71 : 71 ≤ x := by
    by_contra hlt; push Not at hlt
    have : x * x ≤ 70 * 70 := Nat.mul_le_mul (by omega) (by omega)
    omega
  have hxx := sq_mod_two x
  have hxx71 : 71 * x ≤ x * x := Nat.mul_le_mul_right x hx71
  have ha2 : a % 2 = 0 := by omega
  have hx2 : x % 2 = 1 := by omega
  obtain ⟨k, hk⟩ : ∃ k, a = x + 1 + 2 * k := ⟨(a - x - 1) / 2, by omega⟩
  have h6k : 6 * k + 4 * x + 3 = x * x := by omega
  refine Master.eqMaster_realises hCH hadm (eqMasterHyp_of_bounds (k₁ := k) (k₀ := k + 1) hce
    (by omega) (by omega) (by omega) (by omega) (by omega) (by omega) ?_ ?_ (by omega) (by omega))
  · rw [hx, hk]; exact hk1_gen x 1 k le_rfl
  · rw [hx, hk, show x + 1 + 2 * k - 1 = x + 2 * k by omega]
    nlinarith

/-- Gap `y = 0` (squares) via the equitable master criterion. -/
theorem master_y0 (hCH : Master.ChetwyndHilton_1985.{0}) {a b c : ℕ}
    (hadm : AdmissibleProfile a b c) (hab : a ≤ b) (hc : c = b) (hce : c % 2 = 0)
    (hx72 : 72 ≤ b - a) : Realises a b c := by
  have hg := order_gaps hadm hab (by omega)
  have hm := hadm.2.2.2.1
  obtain ⟨x, hx⟩ : ∃ x, b = a + x := ⟨b - a, by omega⟩
  rw [show b - a = x by omega, show c - b = 0 by omega, sq, sq] at hg
  have h3a : 3 * a + 2 * x = x * x := by omega
  have hxx := sq_mod_two x
  have hxx72 : 72 * x ≤ x * x := Nat.mul_le_mul_right x (by omega)
  have hx2 : x % 2 = 1 := by omega
  have ha2 : a % 2 = 1 := by omega
  obtain ⟨k, hk⟩ : ∃ k, a = x + 2 + 2 * k := ⟨(a - x - 2) / 2, by omega⟩
  have h6k : 6 * k + 5 * x + 6 = x * x := by omega
  refine Master.eqMaster_realises hCH hadm (eqMasterHyp_of_bounds (k₁ := k) (k₀ := k + 2) hce
    (by omega) (by omega) (by omega) (by omega) (by omega) (by omega) ?_ ?_ (by omega) (by omega))
  · rw [hx, hk]; exact hk1_gen x 2 k (by norm_num)
  · rw [hx, hk, show x + 2 + 2 * k - 1 = x + 1 + 2 * k by omega]
    nlinarith

/-- **L160** at orders `≥ 5059` from L157 and the master criterion. -/
theorem branchL160_of (hCH : Master.ChetwyndHilton_1985.{0}) (h157 : BranchL157) :
    BranchL160 := by
  intro a b c hadm hab hbc hce h5
  by_cases hy2 : b + 2 ≤ c
  · exact h157 a b c hadm hab hbc hce hy2 (by omega)
  rcases (show c = b + 1 ∨ c = b by omega) with hc | hc
  · exact master_y1 hCH hadm hab hc hce h5
  · refine master_y0 hCH hadm hab hc hce ?_
    have hg := order_gaps hadm hab hbc
    rw [show c - b = 0 by omega, sq] at hg
    by_contra hlt; push Not at hlt
    have : (b - a) * (b - a) ≤ 71 * 71 := Nat.mul_le_mul (by omega) (by omega)
    simp at hg; omega

/-- The large squares `E(p)` from the master criterion. -/
theorem bigSquares_of (hCH : Master.ChetwyndHilton_1985.{0}) : BigSquares := by
  intro p hp hp5 hp3 hbig a b c ha hb hc
  rw [hc]
  have hp6 : p % 6 = 5 := by
    rcases hp.eq_two_or_odd with h | h
    · omega
    · omega
  have hp72 : 72 ≤ p := by
    by_contra hlt; push Not at hlt
    have : p * p ≤ 71 * 71 := Nat.mul_le_mul (by omega) (by omega)
    omega
  have hsum : a + b + b = p * p := by omega
  have hbap : b = a + p := by omega
  have hadm : AdmissibleProfile a b b := by
    have hpp : 72 * p ≤ p * p := Nat.mul_le_mul_right p hp72
    refine ⟨by omega, by omega, by omega, ?_, ?_, by omega, by omega, by omega⟩
    · left; rw [hsum, Nat.mul_mod, hp6]
    · have e1 : (3 : ℤ) * a + 2 * p = p * p := by exact_mod_cast ha
      rw [show (b : ℤ) = a + p by omega]; push_cast; nlinarith
  have hb2 : b % 2 = 0 := by
    obtain ⟨j, hj⟩ : 6 ∣ p + 1 := by omega
    have : 3 * b = 3 * (2 * (p * j)) := by rw [hb, show p * p + p = p * (p + 1) by ring, hj]; ring
    omega
  exact master_y0 hCH hadm (by omega) rfl hb2 (by omega)

/-! ### L161 -/

theorem l161_big (x y a : ℕ) (h3 : 3 * a + 2 * x + y = x * x + x * y + y * y)
    (ht : 72 ≤ x + y) : 6 * (x + y) + 6 ≤ a := by
  have h4 : 3 * ((x + y) * (x + y)) ≤ 4 * (x * x + x * y + y * y) := by
    nlinarith [sq_nonneg ((x : ℤ) - y)]
  have ht2 : 72 * (x + y) ≤ (x + y) * (x + y) := Nat.mul_le_mul_right _ ht
  omega

/-- **L161** at orders `≥ 5059` from the master criterion (roles `A = a`, `B = c`, `C = b`). -/
theorem branchL161_of (hCH : Master.ChetwyndHilton_1985.{0}) : BranchL161 := by
  intro a b c hadm hab hbc hco hx6 h5
  obtain ⟨ha2, hb2⟩ := even_of_odd hadm hco
  have hg := order_gaps hadm hab hbc
  have hadm' : AdmissibleProfile a c b :=
    admissible_swap (admissible_rotate (admissible_rotate hadm))
  obtain ⟨x, hx⟩ : ∃ x, b = a + x := ⟨b - a, by omega⟩
  obtain ⟨y, hy⟩ : ∃ y, c = b + y := ⟨c - b, by omega⟩
  rw [show b - a = x by omega, show c - b = y by omega, sq, sq] at hg
  have h3 : 3 * a + 2 * x + y = x * x + x * y + y * y := by omega
  have ht72 : 72 ≤ x + y := by
    by_contra hlt; push Not at hlt
    have h1 : (x + y) * (x + y) ≤ 71 * 71 := Nat.mul_le_mul (by omega) (by omega)
    have h2 : x * x + x * y + y * y ≤ (x + y) * (x + y) := by nlinarith
    omega
  have hbig := l161_big x y a h3 ht72
  obtain ⟨t, ht⟩ : ∃ t, t = x + y := ⟨_, rfl⟩
  have hy2 : y % 2 = 1 := by omega
  obtain ⟨k, hk⟩ : ∃ k, a = t + 1 + 2 * k := ⟨(a - t - 1) / 2, by omega⟩
  -- `3a = t² - xt + x² - x - t`
  have hkz : (6 * k + 4 * t + 3 + x * t + x : ℤ) = t * t + x * x := by
    have h3z : (3 : ℤ) * a + 2 * x + y = x * x + x * y + y * y := by exact_mod_cast h3
    have haz : (a : ℤ) = t + 1 + 2 * k := by exact_mod_cast hk
    have hyz : (y : ℤ) = t - x := by push_cast [ht]; ring
    rw [haz, hyz] at h3z; linear_combination h3z
  have hk1 : 2 * k * c ≤ a * (a - 1) := by
    rw [show c = a + t by omega, hk]; exact hk1_gen t 1 k le_rfl
  refine realises_swap23 (Master.eqMaster_realises hCH hadm' ?_)
  rcases (show x = 6 ∨ 8 ≤ x by omega) with rfl | hx8
  · refine eqMasterHyp_of_bounds (k₁ := k) (k₀ := k + 1) hb2 (by omega) (by omega) (by omega)
      (by omega) (by omega) (by omega) hk1 ?_ (by omega) (by omega)
    rw [show c = a + t by omega, hk, show t + 1 + 2 * k - 1 = t + 2 * k by omega]
    have : ((t + 1 + 2 * k) * (t + 2 * k) : ℤ) < 2 * (k + 1 + 1) * (t + 1 + 2 * k + t) := by
      nlinarith [sq_nonneg (2 * (t : ℤ) - 19)]
    exact_mod_cast this
  · refine eqMasterHyp_of_bounds (k₁ := k) (k₀ := k + 2) hb2 (by omega) (by omega) (by omega)
      (by omega) (by omega) (by omega) hk1 ?_ (by omega) (by omega)
    rw [show c = a + t by omega, hk, show t + 1 + 2 * k - 1 = t + 2 * k by omega]
    have : ((t + 1 + 2 * k) * (t + 2 * k) : ℤ) < 2 * (k + 2 + 1) * (t + 1 + 2 * k + t) := by
      nlinarith [sq_nonneg ((t : ℤ) - x), show (8 : ℤ) ≤ x by exact_mod_cast hx8]
    exact_mod_cast this

