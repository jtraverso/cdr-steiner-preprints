/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license.
Authors: Juan Pablo Traverso Gianini
-/
module

public import CDRBicolour.PaperIII.Extremes.PlantModel

/-!
# Planting `AAC` blocks, part 3: the packing (item 3, extremes)

`plantP Q r nst odd = tcopies Q ∪ model(r, nst) ∪ (if odd then matching(nst))`:
* copies of the `AAC` triangle (`3|Q|` blocks, `q* ∉ Q`), in the first `3m` points of `A` and `C`;
* the residue gadgets of the 21-point model at `A` points `3m+1+2i` (cycles) and `4m+12+k`
  (stars), `C` points `3m … 3m+7`;
* for `c` odd, the perfect matching `{2i, 2i+1}` of `A` (minus the pairs covered by the
  selected stars), each pair with the `C` point `3m+10 + (i mod (c−3m−10))`.

It is an edge-disjoint packing of `AAC` blocks (`plantP_disj`) with
`3|Q| + r + 3·nst + [odd]·(a/2 − 2·nst)` blocks, every point of `A` in a number of blocks of the
parity of `c` (`plantP_parity`), and leave degree `≤ 81 m + 8 a/(c−3m−10) + 40`.
-/

@[expose] public section

noncomputable section

namespace CDRBicolour.PaperIII.Extremes

open Finset TypedTriangle CDRBicolour.Prefix CDRBicolour.PaperIII CDRBicolour.PaperIII.Exact

/-! ### Two `AAC` blocks without a common `AA` pair or `(A, C)` pair are edge-disjoint -/

section General

variable {V : Type*} [Fintype V] [DecidableEq V] {lab : V → Fin 3}

theorem aac_lab {T : Finset V} (hT : T.val.map lab = aac) {x : V} (hx : x ∈ T) :
    lab x = 0 ∨ lab x = 2 := by
  have : lab x ∈ T.val.map lab := Multiset.mem_map.mpr ⟨x, hx, rfl⟩
  rw [hT] at this
  simpa [aac] using this

theorem aac_disj {T₁ T₂ : Finset V} (h₁ : T₁.val.map lab = aac) (h₂ : T₂.val.map lab = aac)
    (hAA : ∀ x y, lab x = 0 → lab y = 0 → x ≠ y → x ∈ T₁ → y ∈ T₁ → x ∈ T₂ → y ∈ T₂ → False)
    (hAC : ∀ x w, lab x = 0 → lab w = 2 → x ∈ T₁ → w ∈ T₁ → x ∈ T₂ → w ∈ T₂ → False) :
    Disjoint (triEdges T₁) (triEdges T₂) := by
  rw [disjoint_left]
  intro e he1 he2
  induction e using Sym2.ind with
  | _ x y =>
  obtain ⟨x1, y1, hxy⟩ := mem_triEdges_pair.mp he1
  obtain ⟨x2, y2, -⟩ := mem_triEdges_pair.mp he2
  rcases aac_lab h₁ x1 with hx | hx <;> rcases aac_lab h₁ y1 with hy | hy
  · exact hAA x y hx hy hxy x1 y1 x2 y2
  · exact hAC x y hx hy x1 y1 x2 y2
  · exact hAC y x hy hx y1 x1 y2 x2
  · exact hxy (aac_C_unique h₁ x1 y1 hx hy)

end General

/-! ### Indices -/

/-- A vertex from its index. -/
def vx {N : ℕ} [NeZero N] (k : ℕ) : Fin N := ⟨k % N, Nat.mod_lt _ (NeZero.pos N)⟩

theorem vx_val {N : ℕ} [NeZero N] {k : ℕ} (hk : k < N) : (vx k : Fin N).val = k :=
  Nat.mod_eq_of_lt hk

theorem vx_inj {N : ℕ} [NeZero N] {k k' : ℕ} (hk : k < N) (hk' : k' < N)
    (h : (vx k : Fin N) = vx k') : k = k' := by
  have := congrArg Fin.val h
  rwa [vx_val hk, vx_val hk'] at this

/-- Size conditions for planting. -/
structure PlantCond (a b c m : ℕ) : Prop where
  copy : CopyCond a b c m
  hA : 4 * m + 20 ≤ a
  hC : 3 * m + 11 ≤ c

variable {a b c m : ℕ}

instance (a b c : ℕ) [h : Fact (0 < a)] : NeZero (a + b + c) := ⟨by have := h.out; omega⟩

theorem col3_lt_a {k : ℕ} (hk : k < a) (hn : k < a + b + c) [NeZero (a + b + c)] :
    col3 a b c (vx k) = 0 := by
  unfold col3; rw [vx_val hn]; simp [hk]

theorem col3_ge {k : ℕ} (hk : a + b ≤ k) (hn : k < a + b + c) [NeZero (a + b + c)] :
    col3 a b c (vx k) = 2 := by
  unfold col3; rw [vx_val hn]
  have h1 : ¬ k < a := by omega
  have h2 : ¬ k < a + b := by omega
  simp [h1, h2]

theorem col3_val_zero [NeZero (a + b + c)] {x : Fin (a + b + c)} (h : col3 a b c x = 0) :
    x.val < a := by
  unfold col3 at h; split_ifs at h with h1 <;> first | exact h1 | exact absurd h (by decide)

theorem col3_val_two [NeZero (a + b + c)] {x : Fin (a + b + c)} (h : col3 a b c x = 2) :
    a + b ≤ x.val := by
  unfold col3 at h; split_ifs at h with h1 h2 <;> first | omega | exact absurd h (by decide)

end CDRBicolour.PaperIII.Extremes
