# CDR Paper III: Lean source review freeze, preprint 1.0

This archive contains 1,305 selected non-Mathlib dependency modules, the CDRIII aggregate and its four-endpoint axiom check.

The mathematical sources are unchanged from SOURCE_MAP.json. All selected mathematical sources were rebuilt in an isolated project with no initial project objects. Only pinned external Mathlib ecosystem caches were reused. Resumed objects came solely from that same clean run. All four endpoint axiom queries contain only propext, Classical.choice and Quot.sound. Sources and final configuration were hash-verified, with object hashes bound to the completed run. The library configuration restores original provider options; no mathematical proof source changed. Failed attempts and resource adjustments are preserved as historical diagnostics.

For independent reconstruction, install lean/lean-toolchain, enter lean/, obtain the pinned Mathlib dependencies, then run `lake exe cache get`, `lake build CDRIII` and `lake env lean checks/Axioms.lean`. Preserve lake-manifest.json.

Mathlib is pinned at c55e6e786f49471c72fbddbec5415808896aec1e. Dependency objects and caches are not included. Upstream source licenses are retained in lean/THIRD_PARTY_LICENSES.

SHA256SUMS.txt records every other entry. The enclosing review repository records the ZIP hash in 02_validation/v1.0/FREEZE.json. DOI: 10.5281/zenodo.24201563.
