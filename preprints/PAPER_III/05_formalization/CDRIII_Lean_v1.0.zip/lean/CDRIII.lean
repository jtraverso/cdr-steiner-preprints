module

public import CDRBicolour.PaperIII.Unconditional
public import CDRBicolour.KBicolor.CompletionExact
public import CDRBicolour.KBicolor.PrescribedCounting.OptimalPrescribed
public import CDRBicolour.KBicolor.ExactTypesPasch

/-! Paper III public aggregate: established interior results and eventual existence. -/
